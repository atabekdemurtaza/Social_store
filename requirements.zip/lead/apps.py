from django.apps import AppConfig


class LeadConfig(AppConfig):
    name = 'lead'
